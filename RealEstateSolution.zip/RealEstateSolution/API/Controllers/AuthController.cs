using Microsoft.AspNetCore.Mvc;
using AuthService.BusinessLogic;
using AuthService.Models;

[Route("api/auth")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] User user)
    {
        var authenticatedUser = _authService.Authenticate(user.Username, user.Password);
        if (authenticatedUser == null)
        {
            return Unauthorized("Invalid credentials");
        }
        return Ok(authenticatedUser);
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] User user)
    {
        bool isRegistered = _authService.Register(user);
        if (!isRegistered)
        {
            return BadRequest("Registration failed");
        }
        return Ok("User registered successfully");
    }
}
