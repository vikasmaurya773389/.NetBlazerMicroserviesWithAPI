using Microsoft.AspNetCore.Mvc;
using CompanyService.BusinessLogic;
using CompanyService.Models;
using System.Collections.Generic;

[Route("api/company")]
[ApiController]
public class CompanyController : ControllerBase
{
    private readonly ICompanyService _companyService;

    public CompanyController(ICompanyService companyService)
    {
        _companyService = companyService;
    }

    [HttpGet("all")]
    public ActionResult<List<Company>> GetAllCompanies()
    {
        return Ok(_companyService.GetAllCompanies());
    }

    [HttpGet("{id}")]
    public ActionResult<Company> GetCompanyById(int id)
    {
        var company = _companyService.GetCompanyById(id);
        if (company == null) return NotFound();
        return Ok(company);
    }

    [HttpPost("add")]
    public IActionResult AddCompany([FromBody] Company company)
    {
        bool isAdded = _companyService.AddCompany(company);
        if (!isAdded) return BadRequest("Failed to add company");
        return Ok("Company added successfully");
    }
}
