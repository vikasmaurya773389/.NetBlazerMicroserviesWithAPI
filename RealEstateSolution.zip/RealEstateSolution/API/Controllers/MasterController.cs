using Microsoft.AspNetCore.Mvc;
using MasterService.BusinessLogic;
using MasterService.Models;
using System.Collections.Generic;

[Route("api/master")]
[ApiController]
public class MasterController : ControllerBase
{
    private readonly IMasterService _masterService;

    public MasterController(IMasterService masterService)
    {
        _masterService = masterService;
    }

    [HttpGet("all")]
    public ActionResult<List<MasterData>> GetAllMasters()
    {
        return Ok(_masterService.GetAllMasters());
    }
}
