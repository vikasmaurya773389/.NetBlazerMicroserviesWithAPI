﻿using AuthService.BusinessLogic;
using AuthService.DataAccess;
using CompanyService.BusinessLogic;
using CompanyService.DataAccess;
using MasterService.BusinessLogic;
using MasterService.DataAccess;

var builder = WebApplication.CreateBuilder(args);

// **Configuration ko read karna**
var configuration = builder.Configuration;
var connectionString = configuration.GetConnectionString("DefaultConnection");

// **Services Register karna**
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
builder.Services.AddScoped<IMasterRepository, MasterRepository>();

builder.Services.AddScoped<IAuthService, AuthService.BusinessLogic.AuthService>();
builder.Services.AddScoped<ICompanyService, CompanyService.BusinessLogic.CompanyService>();
builder.Services.AddScoped<IMasterService, MasterService.BusinessLogic.MasterService>();

// **Controllers Add karna**
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "RealEstate API v1");
        c.RoutePrefix = string.Empty; // ✅ Default route pr Swagger UI open hoga
    });
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
