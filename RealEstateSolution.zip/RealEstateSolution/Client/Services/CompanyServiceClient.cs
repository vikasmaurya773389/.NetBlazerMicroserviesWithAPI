﻿using CompanyService.BusinessLogic;
using CompanyService.Models;
using System.Collections.Generic;

namespace Client.Services
{
    public class CompanyServiceClient
    {
        private readonly ICompanyService _companyService;

        public CompanyServiceClient(ICompanyService companyService)
        {
            _companyService = companyService;
        }

        public List<Company> GetAllCompanies()
        {
            return _companyService.GetAllCompanies();
        }

        public Company GetCompanyById(int id)
        {
            return _companyService.GetCompanyById(id);
        }

        public bool AddCompany(Company company)
        {
            return _companyService.AddCompany(company);
        }
    }
}
