using AuthService.BusinessLogic;
using AuthService.Models;

namespace Client.Services
{
    public class AuthServiceClient
    {
        private readonly IAuthService _authService;

        public AuthServiceClient(IAuthService authService)
        {
            _authService = authService;
        }

        public User Login(string username, string password)
        {
            return _authService.Authenticate(username, password);
        }

        public bool Register(User user)
        {
            return _authService.Register(user);
        }
    }
}
