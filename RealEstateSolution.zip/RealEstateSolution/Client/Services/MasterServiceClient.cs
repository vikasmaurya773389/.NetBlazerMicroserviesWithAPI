using MasterService.BusinessLogic;
using MasterService.Models;
using System.Collections.Generic;

namespace Client.Services
{
    public class MasterServiceClient
    {
        private readonly IMasterService _masterService;

        public MasterServiceClient(IMasterService masterService)
        {
            _masterService = masterService;
        }

        public List<MasterData> GetAllMasters()
        {
            return _masterService.GetAllMasters();
        }

        public MasterData GetMasterById(int id)
        {
            return _masterService.GetMasterById(id);
        }
    }
}
