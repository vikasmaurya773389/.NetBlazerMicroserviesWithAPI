using AuthService.BusinessLogic;
using AuthService.DataAccess;
using MasterService.BusinessLogic;
using MasterService.DataAccess;
using CompanyService.BusinessLogic;
using CompanyService.DataAccess;
using Client.Services;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;
var connectionString = configuration.GetConnectionString("DefaultConnection");

// Add AuthService dependencies
builder.Services.AddSingleton<IAuthRepository, AuthRepository>();
builder.Services.AddSingleton<IAuthService, AuthService.BusinessLogic.AuthService>();
builder.Services.AddSingleton<AuthServiceClient>();
builder.Services.AddSingleton<IMasterRepository, MasterRepository>();
builder.Services.AddSingleton<IMasterService, MasterService.BusinessLogic.MasterService>();
builder.Services.AddSingleton<MasterServiceClient>();
builder.Services.AddSingleton<ICompanyRepository, CompanyRepository>();
builder.Services.AddSingleton<ICompanyService, CompanyService.BusinessLogic.CompanyService>();
builder.Services.AddSingleton<CompanyServiceClient>();

// Add Razor Pages & Blazor Services
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
