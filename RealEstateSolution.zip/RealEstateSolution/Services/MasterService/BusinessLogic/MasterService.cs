using MasterService.DataAccess;
using MasterService.Models;
using System.Collections.Generic;

namespace MasterService.BusinessLogic
{
    public class MasterService : IMasterService
    {
        private readonly IMasterRepository _masterRepository;

        public MasterService(IMasterRepository masterRepository)
        {
            _masterRepository = masterRepository;
        }

        public List<MasterData> GetAllMasters()
        {
            return _masterRepository.GetAllMasters();
        }

        public MasterData GetMasterById(int id)
        {
            return _masterRepository.GetMasterById(id);
        }
    }
}
