using MasterService.Models;
using System.Collections.Generic;

namespace MasterService.BusinessLogic
{
    public interface IMasterService
    {
        List<MasterData> GetAllMasters();
        MasterData GetMasterById(int id);
    }
}
