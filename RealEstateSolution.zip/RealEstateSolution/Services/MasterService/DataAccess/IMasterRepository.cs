using MasterService.Models;
using System.Collections.Generic;

namespace MasterService.DataAccess
{
    public interface IMasterRepository
    {
        List<MasterData> GetAllMasters();
        MasterData GetMasterById(int id);
    }
}
