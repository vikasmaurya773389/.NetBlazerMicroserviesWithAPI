﻿namespace MasterService;

public class Class1
{

}
