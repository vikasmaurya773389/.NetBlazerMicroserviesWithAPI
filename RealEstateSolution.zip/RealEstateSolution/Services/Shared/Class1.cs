﻿namespace Shared;

public class Class1
{

}
