﻿namespace CompanyService;

public class Class1
{

}
