using CompanyService.Models;
using System.Collections.Generic;

namespace CompanyService.DataAccess
{
    public interface ICompanyRepository
    {
        List<Company> GetAllCompanies();
        Company GetCompanyById(int id);
        bool AddCompany(Company company);
    }
}
