using CompanyService.Models;
using System.Collections.Generic;

namespace CompanyService.BusinessLogic
{
    public interface ICompanyService
    {
        List<Company> GetAllCompanies();
        Company GetCompanyById(int id);
        bool AddCompany(Company company);
    }
}
