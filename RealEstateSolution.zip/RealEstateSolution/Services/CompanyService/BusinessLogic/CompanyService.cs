using CompanyService.DataAccess;
using CompanyService.Models;
using System.Collections.Generic;

namespace CompanyService.BusinessLogic
{
    public class CompanyService : ICompanyService
    {
        private readonly ICompanyRepository _companyRepository;

        public CompanyService(ICompanyRepository companyRepository)
        {
            _companyRepository = companyRepository;
        }

        public List<Company> GetAllCompanies()
        {
            return _companyRepository.GetAllCompanies();
        }

        public Company GetCompanyById(int id)
        {
            return _companyRepository.GetCompanyById(id);
        }

        public bool AddCompany(Company company)
        {
            return _companyRepository.AddCompany(company);
        }
    }
}
