using AuthService.Models;
using System.Collections.Generic;

namespace AuthService.DataAccess
{
    public interface IAuthRepository
    {
        User GetUserByUsername(string username);
        bool RegisterUser(User user);
    }
}
