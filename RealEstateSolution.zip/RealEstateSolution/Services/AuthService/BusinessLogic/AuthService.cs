using AuthService.DataAccess;
using AuthService.Models;
using System;

namespace AuthService.BusinessLogic
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository _authRepository;

        public AuthService(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }

        public User Authenticate(string username, string password)
        {
            var user = _authRepository.GetUserByUsername(username);
            if (user == null || user.Password != password)
            {
                return null; // Authentication failed
            }
            return user;
        }

        public bool Register(User user)
        {
            return _authRepository.RegisterUser(user);
        }
    }
}
