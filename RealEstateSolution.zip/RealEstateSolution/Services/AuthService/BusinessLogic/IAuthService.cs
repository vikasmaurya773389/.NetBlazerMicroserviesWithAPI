using AuthService.Models;

namespace AuthService.BusinessLogic
{
    public interface IAuthService
    {
        User Authenticate(string username, string password);
        bool Register(User user);
    }
}
